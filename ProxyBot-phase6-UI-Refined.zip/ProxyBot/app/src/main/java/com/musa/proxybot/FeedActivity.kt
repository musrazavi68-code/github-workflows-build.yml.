package com.musa.proxybot

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Html
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL

class FeedActivity : AppCompatActivity() {

    // Unverified default list: channels that fail to load are simply skipped.
    private val defaults = listOf(
        "digiato|فناوری", "zoomit|فناوری", "varzesh3|ورزشی", "tarafdari|ورزشی",
        "tasnimnews|خبری", "isna94|خبری", "eghtesadnews|اقتصادی", "khabarfoori|اجتماعی"
    )
    private val prefs by lazy { getSharedPreferences("feed", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var list: LinearLayout
    private lateinit var info: TextView
    private val loop = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 60_000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass() = GradientDrawable().apply {
        setColor(0x33FFFFFF); setStroke(dp(1), 0x66FFFFFF); cornerRadius = dp(20).toFloat()
    }

    private fun channels(): MutableList<String> {
        val s = prefs.getString("chs", null)
        return if (s == null) defaults.toMutableList() else s.split(",").filter { it.isNotBlank() }.toMutableList()
    }
    private fun save(l: List<String>) = prefs.edit().putString("chs", l.joinToString(",")).apply()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(36), dp(16), dp(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
            )
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "کانال‌ها و پیام‌ها"; textSize = 20f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(Button(this).apply {
            text = "+"; textSize = 22f; setTextColor(Color.WHITE); background = glass()
            setOnClickListener { addDialog() }
        }, LinearLayout.LayoutParams(dp(52), dp(52)))
        root.addView(head, LinearLayout.LayoutParams(-1, -2))

        info = TextView(this).apply { setTextColor(0xAAFFFFFF.toInt()); textSize = 12f }
        root.addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })
        setContentView(root)
        render()
    }

    override fun onStart() { super.onStart(); handler.post(loop) }
    override fun onStop() { handler.removeCallbacks(loop); super.onStop() }

    private fun addDialog() {
        val et = EditText(this).apply { hint = "@username یا لینک t.me/..." }
        AlertDialog.Builder(this).setTitle("افزودن کانال یا گروه عمومی").setView(et)
            .setPositiveButton("افزودن") { _, _ ->
                val name = et.text.toString().trim()
                    .replace("https://", "").replace("http://", "")
                    .removePrefix("t.me/").removePrefix("s/").removePrefix("@")
                    .substringBefore("/").substringBefore("?")
                if (!Regex("[A-Za-z0-9_]{4,}").matches(name)) {
                    Toast.makeText(this, "آیدی معتبر نیست", Toast.LENGTH_SHORT).show(); return@setPositiveButton
                }
                val l = channels()
                if (l.none { it.substringBefore("|") == name }) { l.add("$name|شخصی"); save(l) }
                refresh()
            }.setNegativeButton("لغو", null).show()
    }

    private fun refresh() {
        info.text = "در حال بروزرسانی…"
        val chs = channels()
        Thread {
            var okCount = 0
            for (c in chs) {
                val name = c.substringBefore("|")
                try {
                    val con = URL("https://t.me/s/$name").openConnection() as HttpURLConnection
                    con.connectTimeout = 6000; con.readTimeout = 6000
                    val html = try { con.inputStream.bufferedReader().readText() } finally { con.disconnect() }
                    val msgs = Regex("class=\"tgme_widget_message_text[^\"]*\"[^>]*>(.*?)</div>", RegexOption.DOT_MATCHES_ALL)
                        .findAll(html).map { Html.fromHtml(it.groupValues[1], Html.FROM_HTML_MODE_LEGACY).toString().trim() }
                        .filter { it.isNotEmpty() }.toList().takeLast(100).map { it.take(1200) }
                    if (msgs.isNotEmpty()) {
                        prefs.edit().putString("c_$name", msgs.joinToString("\u0001")).apply(); okCount++
                    }
                } catch (_: Exception) { }
            }
            runOnUiThread {
                info.text = if (okCount > 0) "بروزرسانی شد ($okCount از ${chs.size} کانال)"
                else "اتصال برقرار نشد؛ آخرین پیام‌های ذخیره‌شده نمایش داده می‌شود"
                render()
            }
        }.start()
    }

    private fun render() {
        list.removeAllViews()
        for (c in channels()) {
            val name = c.substringBefore("|"); val cat = c.substringAfter("|", "شخصی")
            val cached = prefs.getString("c_$name", null)?.split("\u0001") ?: emptyList()
            list.addView(TextView(this).apply {
                text = "@$name  ·  $cat\n" + (if (cached.isEmpty()) "هنوز پیامی ذخیره نشده"
                    else cached.reversed().joinToString("\n— — —\n") { it.take(280) })
                setTextColor(Color.WHITE); textSize = 14f
                setPadding(dp(14), dp(12), dp(14), dp(12)); background = glass()
                setOnLongClickListener {
                    AlertDialog.Builder(context).setMessage("حذف @$name؟")
                        .setPositiveButton("حذف") { _, _ ->
                            save(channels().filter { it.substringBefore("|") != name }); render()
                        }.setNegativeButton("لغو", null).show(); true
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
    }
}
