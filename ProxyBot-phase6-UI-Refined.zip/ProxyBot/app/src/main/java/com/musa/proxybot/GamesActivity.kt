package com.musa.proxybot

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GamesActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun yekanBold(): Typeface = try {
        Typeface.createFromAsset(assets, "fonts/YekanBakh-Bold.ttf")
    } catch (_: Exception) {
        try { Typeface.createFromAsset(assets, "fonts/Yekan-Bold.ttf") }
        catch (_: Exception) { Typeface.create("sans-serif-black", Typeface.BOLD) }
    }

    private fun pastel(colors: IntArray, stroke: Int = 0xFFFFFFFF.toInt()) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, colors
    ).apply {
        cornerRadius = dp(24).toFloat()
        setStroke(dp(2), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(22), dp(14), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFFFFE0EC.toInt(), 0xFFD8ECFF.toInt(), 0xFFFFF0C7.toInt(), 0xFFD7F8E8.toInt()))
        }

        val scroller = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val adHeader = TextView(this).apply {
            text = "جایگاه تبلیغات بازی‌ها  ✦  حامی سرگرمی سالم"
            textSize = 12f
            typeface = yekanBold()
            setTextColor(0xFF3C4C5D.toInt())
            gravity = Gravity.CENTER
            background = pastel(intArrayOf(0xFFFFF8D8.toInt(), 0xFFFFDCA8.toInt()), 0xFFFFC46B.toInt())
            elevation = dp(7).toFloat()
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }
        content.addView(adHeader, LinearLayout.LayoutParams(-1, dp(42)))

        content.addView(TextView(this).apply {
            text = "دنیای بازی‌ها"
            textSize = 26f
            typeface = yekanBold()
            setTextColor(0xFF344457.toInt())
            gravity = Gravity.CENTER
            setShadowLayer(dp(2).toFloat(), 0f, dp(2).toFloat(), 0x668899AA)
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(9) })
        content.addView(TextView(this).apply {
            text = "یک بازی برگزین، دمی بیاسای و رکوردت را بالا ببر!"
            textSize = 12f
            typeface = yekanBold()
            setTextColor(0xFF566579.toInt())
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(27)))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(gameTile("🔢", "سودوکو", "ذهن‌آزمایی با اعداد", "تبلیغ ویژه سودوکو",
            intArrayOf(0xFFFFD9A8.toInt(), 0xFFFFBFA8.toInt())) {
            startActivity(Intent(this@GamesActivity, SudokuActivity::class.java))
        }, LinearLayout.LayoutParams(0, dp(225), 1f).apply { setMargins(dp(4), dp(8), dp(7), dp(8)) })
        row1.addView(gameTile("🧩", "جدول دانایی", "دانش و واژه‌ها", "جایگاه تبلیغات",
            intArrayOf(0xFFD6E8FF.toInt(), 0xFFB9D9FF.toInt())) {
            startActivity(Intent(this@GamesActivity, CrosswordActivity::class.java))
        }, LinearLayout.LayoutParams(0, dp(225), 1f).apply { setMargins(dp(7), dp(8), dp(4), dp(8)) })
        content.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(gameTile("⚔️", "رستم در تنگه هرمز", "آزمون دلاوری رستم دستان", "تبلیغ حماسی",
            intArrayOf(0xFFE4D9FF.toInt(), 0xFFCAB8F7.toInt())) {
            startActivity(Intent(this@GamesActivity, GameActivity::class.java))
        }, LinearLayout.LayoutParams(0, dp(235), 1f).apply { setMargins(dp(4), dp(8), dp(7), dp(8)) })
        row2.addView(gameTile("🏆", "رکوردها", "امتیازهای روی گوشی", "جایگاه معرفی بازی",
            intArrayOf(0xFFD7F6E7.toInt(), 0xFFB1E8D4.toInt())) {
            android.app.AlertDialog.Builder(this).setTitle("رکوردها")
                .setMessage("رکورد بازی‌ها روی همین گوشی نگهداری می‌شود. جدول امتیازها در نسخه بعدی کامل‌تر می‌شود.")
                .setPositiveButton("باشه", null).show()
        }, LinearLayout.LayoutParams(0, dp(235), 1f).apply { setMargins(dp(7), dp(8), dp(4), dp(8)) })
        content.addView(row2)

        content.addView(TextView(this).apply {
            text = "تمام بازی‌های این بخش برای اجرای اصلی به اینترنت نیاز ندارند."
            textSize = 11f
            typeface = yekanBold()
            setTextColor(0xFF536273.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        })
        content.addView(TextView(this).apply {
            text = "بازگشت به خانه  ←"
            textSize = 13f
            typeface = yekanBold()
            setTextColor(0xFF344457.toInt())
            gravity = Gravity.CENTER
            background = pastel(intArrayOf(0xFFFFFFFF.toInt(), 0xFFE7F0FA.toInt()))
            setPadding(dp(10), dp(9), dp(10), dp(9))
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(-1, dp(48)))

        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun gameTile(
        icon: String,
        title: String,
        subtitle: String,
        adText: String,
        colors: IntArray,
        onClick: () -> Unit
    ): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xAAFFFFFF.toInt())
                cornerRadius = dp(26).toFloat()
                setStroke(dp(1), 0xFFFFFFFF.toInt())
            }
            elevation = dp(13).toFloat()
            setPadding(dp(6), dp(6), dp(6), dp(7))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        val image = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = pastel(colors)
            elevation = dp(4).toFloat()
        }
        image.addView(TextView(this).apply {
            text = icon
            textSize = 46f
            gravity = Gravity.CENTER
            setShadowLayer(dp(4).toFloat(), 0f, dp(3).toFloat(), 0x55667788)
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        image.addView(TextView(this).apply {
            text = title
            textSize = 15f
            typeface = yekanBold()
            setTextColor(0xFF344457.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(2), dp(4), dp(7))
        })
        outer.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))

        // Narrow ad slot below each game image, deliberately kept distinct from the tile title.
        outer.addView(TextView(this).apply {
            text = "✦  $adText  ✦"
            textSize = 8f
            typeface = yekanBold()
            setTextColor(0xFF5A6170.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFFFFF4C5.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFE4B7.toInt())).apply {
                cornerRadius = dp(7).toFloat()
            }
        }, LinearLayout.LayoutParams(-1, dp(18)).apply { topMargin = dp(5) })

        outer.addView(TextView(this).apply {
            text = subtitle
            textSize = 10f
            typeface = yekanBold()
            setTextColor(0xFF647286.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })

        outer.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                    false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(180)
                        .setInterpolator(DecelerateInterpolator()).start()
                    false
                }
                else -> false
            }
        }
        return outer
    }
}
