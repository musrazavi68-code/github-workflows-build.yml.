package com.musa.proxybot

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Random
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    data class P(val server: String, val port: Int, val secret: String, val ping: Long = -1) {
        fun link() = "tg://proxy?server=${Uri.encode(server)}&port=$port&secret=${Uri.encode(secret)}"
    }
    private data class Notice(val source: String, val category: String, val message: String, val opens: Int)

    private val sources = listOf(
        "https://raw.githubusercontent.com/SoliSpirit/mtproto/master/all_proxies.txt",
        "https://raw.githubusercontent.com/ALIILAPRO/MTProtoProxy/main/mtproto.txt"
    )
    private val rx = Regex("server=([^&\\s]+)&port=(\\d+)&secret=([^&\\s]+)")
    private val channelDefaults = listOf(
        "akhbarefori|خبری", "Tasnimnews|خبری", "farsna|خبری", "varzesh3|ورزشی",
        "digiato|فناوری", "zoomit|فناوری", "eghtesadnews|اقتصادی", "khabarfoori|اجتماعی"
    )

    private var best: List<P> = emptyList()
    private var intervalMin = 1
    private var timer: CountDownTimer? = null
    private var initialResume = true
    private var glowAnimator: ObjectAnimator? = null
    private lateinit var cardsBox: FrameLayout
    private lateinit var status: TextView
    private lateinit var countdown: TextView
    private lateinit var connectBtn: Button
    private lateinit var connectGlow: View
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun glass(radius: Int = 22): GradientDrawable = GradientDrawable().apply {
        setColor(0x55FFFFFF)
        setStroke(dp(1), 0xBBADFF00.toInt())
        cornerRadius = dp(radius).toFloat()
    }

    private fun metallicCircle(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(0xFF505962.toInt(), 0xFFE4E8EC.toInt(), 0xFF77828C.toInt(), 0xFFD8DDE1.toInt(), 0xFF424B54.toInt())
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(2), 0xFFB7FF00.toInt())
    }

    private fun displayTypeface(): Typeface = try {
        Typeface.createFromAsset(assets, "fonts/GoodBrush.ttf")
    } catch (_: Exception) {
        Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
    }

    private fun cementBackground(): Drawable = CementTextureDrawable()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
        scan()
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(15), dp(22), dp(15), dp(12))
            background = cementBackground()
        }

        // Advertising header
        val adHeader = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glass(18)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            elevation = dp(4).toFloat()
        }
        adHeader.addView(TextView(this).apply {
            text = "جایگاه تبلیغات"
            textSize = 14f
            typeface = displayTypeface()
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        adHeader.addView(TextView(this).apply {
            text = "معرفی خدمات و کسب‌وکارهای منتخب"
            textSize = 10f
            typeface = displayTypeface()
            setTextColor(0xFFE8EDF0.toInt())
            gravity = Gravity.CENTER
        })
        root.addView(adHeader, LinearLayout.LayoutParams(-1, dp(58)))

        val title = TextView(this).apply {
            text = "PROXY BOT"
            textSize = 29f
            typeface = displayTypeface()
            letterSpacing = 0.08f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setShadowLayer(dp(8).toFloat(), 0f, dp(2).toFloat(), 0x77000000)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(5) })
        root.addView(TextView(this).apply {
            text = "اعلان‌های زنده و منتخب کانال‌های شما"
            textSize = 12f
            typeface = displayTypeface()
            setTextColor(0xFFF3F5F6.toInt())
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(24)))

        cardsBox = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        root.addView(cardsBox, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(7)
            bottomMargin = dp(4)
        })
        renderAnnouncements()

        // Connect capsule with a pulsing phosphor-green halo.
        val connectFrame = FrameLayout(this)
        connectGlow = View(this).apply {
            background = GradientDrawable().apply {
                setColor(0x223BFF00)
                setStroke(dp(2), 0xFFB7FF00.toInt())
                cornerRadius = dp(36).toFloat()
            }
            alpha = 0.10f
        }
        connectFrame.addView(connectGlow, FrameLayout.LayoutParams(-1, -1))
        connectBtn = Button(this).apply {
            text = "اتصال"
            textSize = 20f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF5B636C.toInt(), 0xFF343B43.toInt())).apply {
                cornerRadius = dp(32).toFloat()
                setStroke(dp(1), 0xFF9AA4AC.toInt())
            }
            isEnabled = false
            setOnClickListener { connect() }
        }
        val btnLp = FrameLayout.LayoutParams(-1, dp(58)).apply {
            setMargins(dp(5), dp(4), dp(5), dp(4))
        }
        connectFrame.addView(connectBtn, btnLp)
        root.addView(connectFrame, LinearLayout.LayoutParams(-1, dp(66)))

        countdown = TextView(this).apply {
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 13f
            typeface = displayTypeface()
            setOnClickListener {
                intervalMin = when (intervalMin) { 1 -> 5; 5 -> 10; else -> 1 }
                Toast.makeText(context, "بازه بررسی: $intervalMin دقیقه", Toast.LENGTH_SHORT).show()
                startTimer()
            }
        }
        root.addView(countdown, LinearLayout.LayoutParams(-1, dp(27)))

        status = TextView(this).apply {
            setTextColor(0xFFEAF2E7.toInt())
            gravity = Gravity.CENTER
            textSize = 11f
            typeface = displayTypeface()
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(22)))

        val op = TextView(this).apply {
            text = "تشخیص اپراتور"
            textSize = 11f
            typeface = displayTypeface()
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(16)
            setOnClickListener { operatorDialog() }
        }
        root.addView(op, LinearLayout.LayoutParams(dp(138), dp(32)).apply {
            gravity = Gravity.CENTER
            topMargin = dp(2)
        })

        root.addView(bottomMetalNavigation(), LinearLayout.LayoutParams(-1, dp(91)).apply {
            topMargin = dp(8)
        })
        setContentView(root)
    }

    private fun renderAnnouncements() {
        if (cardsBox.childCount > 0) {
            for (i in 0 until cardsBox.childCount) {
                (cardsBox.getChildAt(i).tag as? ObjectAnimator)?.cancel()
            }
        }
        cardsBox.removeAllViews()
        val prefs = getSharedPreferences("feed", MODE_PRIVATE)
        val rawChannels = prefs.getString("chs", null)
            ?.split(",")?.filter { it.isNotBlank() } ?: channelDefaults

        val notices = rawChannels.mapNotNull { entry ->
            val name = entry.substringBefore("|").trim()
            val cat = entry.substringAfter("|", "عمومی").trim()
            val cached = prefs.getString("c_$name", null)
                ?.split("\u0001")?.filter { it.isNotBlank() }.orEmpty()
            val msg = cached.lastOrNull()?.replace(Regex("\\s+"), " ")
                ?: "هنوز پیامی در حافظه نیست؛ برای دریافت پیام‌های تازه، بخش پیام‌رسان را باز کنید."
            val opens = prefs.getInt("home_opens_$name", 0)
            Notice(name, cat, msg, opens)
        }.shuffled().sortedByDescending { it.opens }.take(5)

        notices.forEachIndexed { index, notice ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(9), dp(14), dp(9))
                background = glass(21)
                elevation = dp(8 - index.coerceAtMost(5)).toFloat()
                alpha = 0.96f
            }
            card.addView(TextView(this).apply {
                text = "@${notice.source}   •   ${notice.category}"
                textSize = 13f
                typeface = displayTypeface()
                setTextColor(Color.WHITE)
            })
            card.addView(TextView(this).apply {
                text = notice.message.take(125) + if (notice.message.length > 125) "…" else ""
                textSize = 11f
                typeface = displayTypeface()
                setTextColor(0xFFF5F7F8.toInt())
                setPadding(0, dp(4), 0, dp(3))
            })
            card.addView(TextView(this).apply {
                text = "بازدیدهای شما: ${notice.opens}   ·   لمس برای مطالعه"
                textSize = 9f
                typeface = displayTypeface()
                setTextColor(0xFFE2FFB7.toInt())
            })
            val lp = FrameLayout.LayoutParams(
                if (index == 0) dp(316) else dp(300 - index * 8), dp(92),
                Gravity.TOP or (if (index % 2 == 0) Gravity.END else Gravity.START)
            ).apply {
                topMargin = dp(index * 34)
                if (index % 2 == 0) rightMargin = dp(1) else leftMargin = dp(2)
            }
            card.translationX = if (index % 2 == 0) dp(3).toFloat() else -dp(4).toFloat()
            makeDraggable(card) {
                prefs.edit().putInt("home_opens_${notice.source}", notice.opens + 1).apply()
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("@${notice.source} · ${notice.category}")
                    .setMessage(notice.message)
                    .setPositiveButton("بستن", null)
                    .show()
            }
            cardsBox.addView(card, lp)
            val floatAnimation = ObjectAnimator.ofFloat(card, "translationY", -dp(2).toFloat(), dp(2).toFloat()).apply {
                duration = 1800L + index * 120L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
            }
            card.tag = floatAnimation
            floatAnimation.start()
        }
    }

    private fun makeDraggable(view: View, onTap: () -> Unit) {
        var downX = 0f
        var downY = 0f
        var moved = false
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    (v.tag as? ObjectAnimator)?.cancel()
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    v.translationX = dx
                    v.translationY = dy * 0.35f
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (v.translationX < -dp(85)) {
                        v.animate().translationX(-cardsBox.width.toFloat() - dp(40)).alpha(0f)
                            .setDuration(260).withEndAction { cardsBox.removeView(v) }.start()
                    } else {
                        v.animate().translationX(0f).translationY(0f)
                            .alpha(1f).setDuration(260).setInterpolator(AccelerateDecelerateInterpolator())
                            .withEndAction { (v.tag as? ObjectAnimator)?.start() }.start()
                        if (!moved) onTap()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun bottomMetalNavigation(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val items = listOf(
            Triple("✉", "پیام‌رسان") { startActivity(Intent(this, FeedActivity::class.java)) },
            Triple("✧", "خلاصه AI") { startActivity(Intent(this, SummaryActivity::class.java)) },
            Triple("⚔", "حالت گیم") { startActivity(Intent(this, GamesActivity::class.java)) }
        )
        items.forEach { (icon, title, action) ->
            val circle = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = metallicCircle()
                elevation = dp(9).toFloat()
                setOnClickListener { action() }
                isClickable = true
                isFocusable = true
            }
            circle.addView(TextView(this).apply {
                text = icon
                textSize = 23f
                setTextColor(0xFF202830.toInt())
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
            })
            circle.addView(TextView(this).apply {
                text = title
                textSize = 9f
                setTextColor(0xFF1E272E.toInt())
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
            })
            val cell = FrameLayout(this).apply {
                addView(circle, FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER))
            }
            bar.addView(cell, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return bar
    }

    private fun setConnectReady(ready: Boolean) {
        connectBtn.isEnabled = ready
        connectBtn.text = if (ready) "اتصال" else "در حال جست‌وجوی پروکسی…"
        connectBtn.background = if (ready) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFFB7FF00.toInt(), 0xFF57D92B.toInt(), 0xFF17B978.toInt())).apply {
                cornerRadius = dp(32).toFloat()
                setStroke(dp(1), 0xFFE3FFC0.toInt())
            }
        } else {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF59636D.toInt(), 0xFF303941.toInt())).apply {
                cornerRadius = dp(32).toFloat()
                setStroke(dp(1), 0xFF87919A.toInt())
            }
        }
        connectBtn.setTextColor(if (ready) 0xFF13200C.toInt() else Color.WHITE)
        if (ready) startConnectGlow() else stopConnectGlow()
    }

    private fun startConnectGlow() {
        glowAnimator?.cancel()
        connectGlow.alpha = 0.15f
        glowAnimator = ObjectAnimator.ofFloat(connectGlow, "alpha", 0.15f, 0.8f, 0.15f).apply {
            duration = 1450
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        connectGlow.animate().scaleX(1.03f).scaleY(1.12f).setDuration(800).start()
    }

    private fun stopConnectGlow() {
        glowAnimator?.cancel()
        connectGlow.alpha = 0.05f
        connectGlow.scaleX = 1f
        connectGlow.scaleY = 1f
    }

    private fun download(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    private fun scan() {
        timer?.cancel()
        status.text = "در حال دریافت و آزمایش پروکسی‌ها…"
        countdown.text = ""
        setConnectReady(false)

        Thread {
            val all = ArrayList<P>()
            for (u in sources) {
                try {
                    val t = download(u)
                    rx.findAll(t).forEach { m ->
                        val port = m.groupValues[2].toIntOrNull()
                        if (port != null) all.add(P(m.groupValues[1], port, m.groupValues[3]))
                    }
                } catch (_: Exception) { }
            }
            val cand = all.distinctBy { "${it.server}:${it.port}:${it.secret}" }.shuffled().take(150)
            val pool = Executors.newFixedThreadPool(30)
            val futures = cand.map { p ->
                pool.submit<P?> {
                    val t0 = System.nanoTime()
                    try {
                        Socket().use { it.connect(InetSocketAddress(p.server, p.port), 2500) }
                        p.copy(ping = (System.nanoTime() - t0) / 1_000_000)
                    } catch (_: Exception) { null }
                }
            }
            val ok = futures.mapNotNull {
                try { it.get(22, TimeUnit.SECONDS) } catch (_: Exception) { null }
            }.sortedBy { it.ping }
            pool.shutdownNow()

            runOnUiThread {
                best = ok.take(3)
                renderProxyResult(ok.size, cand.size)
                startTimer()
            }
        }.start()
    }

    private fun renderProxyResult(okCount: Int, total: Int) {
        if (best.isEmpty()) {
            status.text = "پروکسی پاسخ‌گو پیدا نشد؛ در نوبت بعد دوباره تلاش می‌شود"
            setConnectReady(false)
        } else {
            status.text = "$okCount از $total پروکسی در آزمون TCP پاسخ دادند؛ اتصال نهایی در تلگرام تأیید می‌شود"
            setConnectReady(true)
        }
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(intervalMin * 60_000L, 1000) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                countdown.text = "بررسی بعدی: %02d:%02d  ·  لمس برای تغییر بازه".format(s / 60, s % 60)
            }
            override fun onFinish() { scan() }
        }.start()
    }

    private fun operatorDialog() {
        val et = android.widget.EditText(this).apply {
            hint = "مثلاً 09121234567"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("شماره سیم‌کارت (اختیاری)")
            .setView(et)
            .setPositiveButton("تشخیص") { _, _ ->
                val op = OperatorDetector.detect(et.text.toString())
                Toast.makeText(this, "اپراتور احتمالی: $op", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun connect() {
        val p = best.firstOrNull() ?: return
        connectBtn.text = "در حال ارسال درخواست…"
        status.text = "درخواست اتصال به تلگرام فرستاده می‌شود؛ نتیجه را داخل تلگرام تأیید کنید."
        startConnectGlow()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.link())))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "تلگرام روی گوشی نصب نیست", Toast.LENGTH_LONG).show()
            connectBtn.text = "اتصال"
        }
    }

    override fun onResume() {
        super.onResume()
        if (initialResume) initialResume = false else if (::cardsBox.isInitialized) renderAnnouncements()
    }

    override fun onDestroy() {
        timer?.cancel()
        glowAnimator?.cancel()
        super.onDestroy()
    }
}

/** Cement-like gradient with a subtle grain texture, drawn natively (no image dependency). */
private class CementTextureDrawable : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val random = Random(27)
    private val grains = List(520) { Triple(random.nextFloat(), random.nextFloat(), random.nextFloat()) }

    override fun draw(canvas: Canvas) {
        val b = bounds
        paint.shader = LinearGradient(0f, 0f, b.width().toFloat(), b.height().toFloat(),
            intArrayOf(0xFF747A80.toInt(), 0xFF9AA0A5.toInt(), 0xFF666D74.toInt(), 0xFF343B43.toInt()),
            null, Shader.TileMode.CLAMP)
        canvas.drawRect(b, paint)
        paint.shader = null
        grains.forEach { (x, y, r) ->
            paint.color = if (r > 0.5f) 0x16FFFFFF else 0x16000000
            val radius = 0.35f + r * 0.8f
            canvas.drawCircle(b.left + x * b.width(), b.top + y * b.height(), radius, paint)
        }
        paint.color = Color.WHITE
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) { paint.colorFilter = colorFilter }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = android.graphics.PixelFormat.OPAQUE
}
