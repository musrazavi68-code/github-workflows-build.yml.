package com.musa.proxybot

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.sqrt

class SummaryActivity : AppCompatActivity() {

    private val feed by lazy { getSharedPreferences("feed", MODE_PRIVATE) }
    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private lateinit var out: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass() = GradientDrawable().apply {
        setColor(0x33FFFFFF); setStroke(dp(1), 0x66FFFFFF); cornerRadius = dp(20).toFloat()
    }

    /** channel name -> cached messages */
    private fun collect(): Map<String, List<String>> {
        val chs = feed.getString("chs", null)?.split(",")?.map { it.substringBefore("|") } ?: emptyList()
        val m = LinkedHashMap<String, List<String>>()
        for (c in chs) {
            val msgs = feed.getString("c_$c", null)?.split("\u0001")?.filter { it.isNotBlank() }
            if (!msgs.isNullOrEmpty()) m[c] = msgs
        }
        return m
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val backdrop = FrameLayout(this)
        val stars = MagicStarField(this)
        backdrop.addView(stars, FrameLayout.LayoutParams(-1, -1))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(28), dp(16), dp(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xD0101A2A.toInt(), 0xC51C3042.toInt(), 0xD010202E.toInt())
            )
        }

        val magicHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass()
            setPadding(dp(8), dp(7), dp(8), dp(7))
        }
        magicHeader.addView(TextView(this).apply {
            text = "🪄"
            textSize = 28f
            gravity = Gravity.CENTER
            setShadowLayer(dp(10).toFloat(), 0f, 0f, 0xFFB7FFEA.toInt())
        })
        magicHeader.addView(TextView(this).apply {
            text = "خلاصه‌ساز هوشمند  ✦"
            textSize = 21f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setShadowLayer(dp(7).toFloat(), 0f, 0f, 0xFF78E8FF.toInt())
        })
        root.addView(magicHeader, LinearLayout.LayoutParams(-1, dp(62)))
        root.addView(TextView(this).apply {
            text = "ستاره‌های پیام‌ها را به یک روایت روشن تبدیل کن"
            textSize = 11f
            setTextColor(0xFFE1EDFF.toInt())
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(30)))

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xDD42677D.toInt(), 0xDD384A6A.toInt())).apply {
                setStroke(dp(1), 0xFF9AFFD7.toInt())
                cornerRadius = dp(22).toFloat()
            }
            setOnClickListener { f() }
        }
        root.addView(btn("✧  خلاصه آفلاین (بدون اینترنت و کلید)") { offline() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })

        val key = EditText(this).apply {
            hint = "کلید API انتروپیک (اختیاری، فقط روی همین گوشی ذخیره می‌شود)"
            setTextColor(Color.WHITE)
            setHintTextColor(0xCCFFFFFF.toInt())
            textSize = 12f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(cfg.getString("key", ""))
            background = glass()
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(key, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(11) })
        root.addView(btn("🪄  خلاصه‌سازی با هوش مصنوعی (آنلاین)") {
            val k = key.text.toString().trim()
            if (k.isEmpty()) Toast.makeText(this, "اول کلید API را وارد کن", Toast.LENGTH_SHORT).show()
            else { cfg.edit().putString("key", k).apply(); online(k) }
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(7) })

        out = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = glass()
            text = "پیام‌های ذخیره‌شده از تلگرام و منابع دیگر را خلاصه کن؛ نتیجه برای مطالعه آفلاین در همین صفحه نمایش داده می‌شود."
        }
        root.addView(ScrollView(this).apply { addView(out) },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12) })

        backdrop.addView(root, FrameLayout.LayoutParams(-1, -1))
        setContentView(backdrop)
    }

    private val stop = setOf("که", "این", "آن", "با", "برای", "از", "در", "به", "را", "هم", "است", "شد",
        "شده", "شود", "کرد", "کرده", "های", "ها", "یک", "تا", "بر", "اما", "یا", "خود", "کند", "بود", "می")

    private fun offline() {
        val data = collect()
        if (data.isEmpty()) { out.text = "پیام ذخیره‌شده‌ای وجود ندارد."; return }
        val sb = StringBuilder()
        for ((ch, msgs) in data) {
            val sents = msgs.flatMap { it.split(Regex("[.!؟?۔\\n]+")) }.map { it.trim() }.filter { it.length > 15 }
            val words = { s: String -> s.split(Regex("[\\s،,:;()«»\"'…\\-]+")).filter { it.length >= 3 && it !in stop } }
            val freq = HashMap<String, Int>()
            sents.forEach { s -> words(s).forEach { freq[it] = (freq[it] ?: 0) + 1 } }
            val top = sents.withIndex().sortedByDescending { (_, s) ->
                val w = words(s); if (w.isEmpty()) 0.0 else w.sumOf { freq[it] ?: 0 }.toDouble() / sqrt(w.size.toDouble())
            }.take(2).sortedBy { it.index }.map { it.value }
            sb.append("• @").append(ch).append("\n")
            sb.append(if (top.isEmpty()) msgs.last().take(200) else top.joinToString("\n")).append("\n\n")
        }
        out.text = sb.toString().trim()
    }

    private fun online(key: String) {
        val data = collect()
        if (data.isEmpty()) { out.text = "پیام ذخیره‌شده‌ای وجود ندارد."; return }
        out.text = "در حال خلاصه‌سازی…"
        val text = data.entries.joinToString("\n\n") { (c, m) -> "@$c:\n" + m.joinToString("\n- ", "- ") }.take(12000)
        Thread {
            val result = try {
                val body = JSONObject()
                    .put("model", "claude-sonnet-5-5")
                    .put("max_tokens", 1000)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content",
                        "پیام‌های زیر از چند کانال تلگرام است. برای هر کانال، خلاصه کوتاه فارسی (۱ تا ۲ جمله) بنویس.\n\n$text")))
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode in 200..299) {
                    JSONObject(c.inputStream.bufferedReader().readText())
                        .getJSONArray("content").getJSONObject(0).getString("text")
                } else "خطا (${c.responseCode}): کلید یا اینترنت را بررسی کن."
            } catch (e: Exception) { "اتصال برقرار نشد: ${e.message}" }
            runOnUiThread { out.text = result }
        }.start()
    }
}


/** Soft animated star field for the AI summary screen. */
private class MagicStarField(context: Context) : View(context) {
    private data class Star(val x: Float, val y: Float, val size: Float, val speed: Float, val phase: Float)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stars = ArrayList<Star>()
    private var tick = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 9000L
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { tick = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        stars.clear()
        val random = java.util.Random(42)
        repeat(74) {
            stars.add(Star(random.nextFloat() * w, random.nextFloat() * h,
                1.2f + random.nextFloat() * 2.6f, 5f + random.nextFloat() * 20f, random.nextFloat() * 6.28f))
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        stars.forEachIndexed { index, star ->
            val y = (star.y - tick * star.speed * 3f + height + (index * 3 % 17)) % height.coerceAtLeast(1)
            val pulse = (0.45f + 0.55f * kotlin.math.abs(kotlin.math.sin(tick * 6.28f + star.phase)))
            paint.color = Color.argb((70 + 150 * pulse).toInt().coerceIn(0, 220), 175, 244, 255)
            paint.setShadowLayer(star.size * 4f, 0f, 0f, 0xFF7CEBFF.toInt())
            canvas.drawCircle(star.x, y, star.size * pulse, paint)
            if (index % 6 == 0) {
                canvas.drawRect(star.x - star.size * 2f, y - 0.6f, star.x + star.size * 2f, y + 0.6f, paint)
                canvas.drawRect(star.x - 0.6f, y - star.size * 2f, star.x + 0.6f, y + star.size * 2f, paint)
            }
            paint.clearShadowLayer()
        }
    }
}
