package com.musa.proxybot

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    data class P(val server: String, val port: Int, val secret: String, val ping: Long = -1) {
        fun link() = "tg://proxy?server=$server&port=$port&secret=$secret"
    }

    private val sources = listOf(
        "https://raw.githubusercontent.com/SoliSpirit/mtproto/master/all_proxies.txt",
        "https://raw.githubusercontent.com/ALIILAPRO/MTProtoProxy/main/mtproto.txt"
    )
    private val rx = Regex("server=([^&\\s]+)&port=(\\d+)&secret=([^&\\s]+)")

    private var best: List<P> = emptyList()
    private var intervalMin = 1
    private var timer: CountDownTimer? = null

    private lateinit var cardsBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var countdown: TextView
    private lateinit var connectBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun glass(radius: Int = 20): GradientDrawable = GradientDrawable().apply {
        setColor(0x33FFFFFF)
        setStroke(dp(1), 0x66FFFFFF)
        cornerRadius = dp(radius).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(36), dp(16), dp(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
            )
        }

        // Ad banner
        root.addView(TextView(this).apply {
            text = "فضای تبلیغات"
            setTextColor(0xCCFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = glass()
        }, LinearLayout.LayoutParams(-1, dp(64)))

        // Cascading glass cards
        cardsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
        }
        root.addView(cardsBox, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(20) })

        // Connect button
        connectBtn = Button(this).apply {
            text = "اتصال"
            textSize = 20f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(0xFF2AABEE.toInt())
                cornerRadius = dp(32).toFloat()
            }
            isEnabled = false
            setOnClickListener { connect() }
        }
        root.addView(connectBtn, LinearLayout.LayoutParams(-1, dp(64)))

        countdown = TextView(this).apply {
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 15f
            setOnClickListener {
                intervalMin = when (intervalMin) { 1 -> 5; 5 -> 10; else -> 1 }
                Toast.makeText(context, "بازه چرخش: $intervalMin دقیقه", Toast.LENGTH_SHORT).show()
                startTimer()
            }
        }
        root.addView(countdown, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        status = TextView(this).apply {
            setTextColor(0xAAFFFFFF.toInt())
            gravity = Gravity.CENTER
            textSize = 13f
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        root.addView(Button(this).apply {
            text = "تشخیص اپراتور از شماره"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = glass()
            setOnClickListener { operatorDialog() }
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(10) })

        // Bottom bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = glass(28)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        listOf("پیام‌رسان", "خلاصه‌ساز AI", "حالت گیم").forEach { label ->
            bar.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    if (label == "پیام‌رسان") startActivity(Intent(context, FeedActivity::class.java))
                    else if (label == "حالت گیم") startActivity(Intent(context, GamesActivity::class.java))
                    else if (label.startsWith("خلاصه")) startActivity(Intent(context, SummaryActivity::class.java))
                    else Toast.makeText(context, "$label در مرحله بعد اضافه می‌شود", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        setContentView(root)
        scan()
    }

    private fun download(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    private fun scan() {
        timer?.cancel()
        status.text = "در حال دریافت و تست پروکسی‌ها…"
        countdown.text = ""
        connectBtn.isEnabled = false

        Thread {
            val all = ArrayList<P>()
            for (u in sources) {
                try {
                    val t = download(u)
                    rx.findAll(t).forEach { m ->
                        val port = m.groupValues[2].toIntOrNull()
                        if (port != null) all.add(P(m.groupValues[1], port, m.groupValues[3]))
                    }
                } catch (_: Exception) { }
            }
            val cand = all.distinctBy { "${it.server}:${it.port}" }.shuffled().take(150)

            val pool = Executors.newFixedThreadPool(40)
            val futures = cand.map { p ->
                pool.submit<P?> {
                    val t0 = System.nanoTime()
                    try {
                        Socket().use { it.connect(InetSocketAddress(p.server, p.port), 2500) }
                        p.copy(ping = (System.nanoTime() - t0) / 1_000_000)
                    } catch (e: Exception) { null }
                }
            }
            val ok = futures.mapNotNull {
                try { it.get(20, TimeUnit.SECONDS) } catch (e: Exception) { null }
            }.sortedBy { it.ping }
            pool.shutdownNow()

            runOnUiThread {
                best = ok.take(3)
                render(ok.size, cand.size)
                startTimer()
            }
        }.start()
    }

    private fun render(okCount: Int, total: Int) {
        cardsBox.removeAllViews()
        best.forEachIndexed { i, p ->
            val card = TextView(this).apply {
                text = "${p.server}:${p.port}\nپینگ: ${p.ping} ms"
                setTextColor(Color.WHITE)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = glass()
                scaleX = 1f - 0.04f * i
                alpha = 1f - 0.2f * i
                elevation = dp(8 - i * 2).toFloat()
            }
            cardsBox.addView(card, LinearLayout.LayoutParams(-1, dp(76)).apply {
                if (i > 0) topMargin = -dp(14)
            })
        }
        if (best.isEmpty()) {
            status.text = "پروکسی سالم پیدا نشد؛ بعد از شمارنده دوباره تلاش می‌شود"
        } else {
            status.text = "$okCount از $total پروکسی پاسخ دادند"
            connectBtn.isEnabled = true
        }
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(intervalMin * 60_000L, 1000) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                countdown.text = "بروزرسانی بعدی: %02d:%02d (برای تغییر بازه لمس کن)".format(s / 60, s % 60)
            }
            override fun onFinish() { scan() }
        }.start()
    }

    private fun operatorDialog() {
        val et = android.widget.EditText(this).apply {
            hint = "مثلاً 09121234567"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("شماره سیم‌کارت")
            .setView(et)
            .setPositiveButton("تشخیص") { _, _ ->
                val op = OperatorDetector.detect(et.text.toString())
                Toast.makeText(this, "اپراتور: $op (حدسی؛ پورت کردن شماره ممکن است نتیجه را عوض کند)", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun connect() {
        val p = best.firstOrNull() ?: return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.link())))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "تلگرام روی گوشی نصب نیست", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
