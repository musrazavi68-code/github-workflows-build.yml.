package com.musa.proxybot

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GamesActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass() = GradientDrawable().apply {
        setColor(0x33FFFFFF); setStroke(dp(1), 0x66FFFFFF); cornerRadius = dp(20).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(36), dp(16), dp(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
            )
        }
        root.addView(TextView(this).apply {
            text = "حالت گیم"; textSize = 22f; setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "پیشرفت هر بازی روی خود گوشی ذخیره می‌شود و با قطع شدن اتصال از بین نمی‌رود."
            textSize = 12f; setTextColor(0xAAFFFFFF.toInt())
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        fun game(t: String, f: () -> Unit) = root.addView(Button(this).apply {
            text = t; textSize = 17f; isAllCaps = false; setTextColor(Color.WHITE); background = glass()
            setOnClickListener { f() }
        }, LinearLayout.LayoutParams(-1, dp(84)).apply { topMargin = dp(16) })

        game("سودوکو") { startActivity(Intent(this, SudokuActivity::class.java)) }
        game("جدول اطلاعات عمومی") { startActivity(Intent(this, CrosswordActivity::class.java)) }
        game("رستم در تنگه هرمز") { startActivity(Intent(this, GameActivity::class.java)) }
        setContentView(root)
    }
}
