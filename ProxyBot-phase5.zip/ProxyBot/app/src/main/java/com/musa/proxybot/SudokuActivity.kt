package com.musa.proxybot

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SudokuActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("sudoku", MODE_PRIVATE) }
    private var given = IntArray(81)
    private var cur = IntArray(81)
    private var sel = -1
    private lateinit var cells: Array<TextView>

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun generate() {
        val g = (0 until 3).shuffled()
        val rows = g.flatMap { b -> (0 until 3).shuffled().map { b * 3 + it } }
        val cols = (0 until 3).shuffled().flatMap { b -> (0 until 3).shuffled().map { b * 3 + it } }
        val nums = (1..9).shuffled()
        val sol = IntArray(81)
        for (r in 0 until 9) for (c in 0 until 9) {
            val rr = rows[r]; val cc = cols[c]
            sol[r * 9 + c] = nums[(3 * (rr % 3) + rr / 3 + cc) % 9]
        }
        given = sol.copyOf()
        (0 until 81).shuffled().take(45).forEach { given[it] = 0 }
        cur = given.copyOf()
        sel = -1
    }

    private fun save() {
        prefs.edit().putString("given", given.joinToString("")).putString("cur", cur.joinToString("")).apply()
    }

    private fun restore(): Boolean {
        val g = prefs.getString("given", null) ?: return false
        val c = prefs.getString("cur", null) ?: return false
        if (g.length != 81 || c.length != 81) return false
        given = IntArray(81) { g[it] - '0' }
        cur = IntArray(81) { c[it] - '0' }
        return true
    }

    private fun conflict(i: Int): Boolean {
        val v = cur[i]; if (v == 0) return false
        val r = i / 9; val c = i % 9
        for (j in 0 until 81) {
            if (j == i || cur[j] != v) continue
            val jr = j / 9; val jc = j % 9
            if (jr == r || jc == c || (jr / 3 == r / 3 && jc / 3 == c / 3)) return true
        }
        return false
    }

    private fun refresh() {
        for (i in 0 until 81) {
            val t = cells[i]
            t.text = if (cur[i] == 0) "" else cur[i].toString()
            t.setTextColor(
                when {
                    conflict(i) -> 0xFFFF8A80.toInt()
                    given[i] != 0 -> Color.WHITE
                    else -> 0xFF80D8FF.toInt()
                }
            )
            t.setBackgroundColor(
                when {
                    i == sel -> 0x88FFFFFF.toInt()
                    given[i] != 0 -> 0x44FFFFFF
                    else -> 0x22FFFFFF
                }
            )
        }
        if (cur.all { it != 0 } && (0 until 81).none { conflict(it) }) {
            Toast.makeText(this, "آفرین! سودوکو حل شد 🎉", Toast.LENGTH_LONG).show()
        }
    }

    private fun put(v: Int) {
        if (sel < 0 || given[sel] != 0) return
        cur[sel] = v; save(); refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!restore()) { generate(); save() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(32), dp(12), dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
            )
        }
        root.addView(TextView(this).apply { text = "سودوکو"; textSize = 20f; setTextColor(Color.WHITE) })

        val size = (resources.displayMetrics.widthPixels - dp(24) - dp(8)) / 9
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val list = ArrayList<TextView>()
        for (r in 0 until 9) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 9) {
                val idx = r * 9 + c
                val t = TextView(this).apply {
                    gravity = Gravity.CENTER; textSize = 20f
                    setOnClickListener { sel = idx; refresh() }
                }
                row.addView(t, LinearLayout.LayoutParams(size, size).apply {
                    setMargins(dp(1), dp(1), if (c % 3 == 2) dp(4) else dp(1), if (r % 3 == 2) dp(4) else dp(1))
                })
                list.add(t)
            }
            grid.addView(row)
        }
        cells = list.toTypedArray()
        root.addView(grid, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12); gravity = Gravity.CENTER_HORIZONTAL })

        fun padRow(items: List<Pair<String, () -> Unit>>) {
            val row = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR }
            items.forEach { (label, f) ->
                row.addView(Button(this).apply {
                    text = label; isAllCaps = false; setTextColor(Color.WHITE)
                    setBackgroundColor(0x33FFFFFF); setOnClickListener { f() }
                }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
            root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
        padRow((1..5).map { n -> n.toString() to { put(n) } })
        padRow((6..9).map { n -> n.toString() to { put(n) } } + listOf("پاک" to { put(0) }))
        padRow(listOf("بازی جدید" to { generate(); save(); refresh() }))

        setContentView(root)
        refresh()
    }
}
