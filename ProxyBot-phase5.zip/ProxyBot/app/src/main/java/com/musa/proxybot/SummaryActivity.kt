package com.musa.proxybot

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.sqrt

class SummaryActivity : AppCompatActivity() {

    private val feed by lazy { getSharedPreferences("feed", MODE_PRIVATE) }
    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private lateinit var out: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass() = GradientDrawable().apply {
        setColor(0x33FFFFFF); setStroke(dp(1), 0x66FFFFFF); cornerRadius = dp(20).toFloat()
    }

    /** channel name -> cached messages */
    private fun collect(): Map<String, List<String>> {
        val chs = feed.getString("chs", null)?.split(",")?.map { it.substringBefore("|") } ?: emptyList()
        val m = LinkedHashMap<String, List<String>>()
        for (c in chs) {
            val msgs = feed.getString("c_$c", null)?.split("\u0001")?.filter { it.isNotBlank() }
            if (!msgs.isNullOrEmpty()) m[c] = msgs
        }
        return m
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(36), dp(16), dp(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
            )
        }
        root.addView(TextView(this).apply {
            text = "خلاصه‌ساز پیام‌ها"; textSize = 20f; setTextColor(Color.WHITE)
        })

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE); background = glass()
            setOnClickListener { f() }
        }
        root.addView(btn("خلاصه آفلاین (بدون اینترنت و کلید)") { offline() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })

        val key = EditText(this).apply {
            hint = "کلید API انتروپیک (اختیاری، فقط روی همین گوشی ذخیره می‌شود)"
            setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); textSize = 12f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(cfg.getString("key", ""))
        }
        root.addView(key, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        root.addView(btn("خلاصه با Claude (نیاز به اینترنت)") {
            val k = key.text.toString().trim()
            if (k.isEmpty()) Toast.makeText(this, "اول کلید API را وارد کن", Toast.LENGTH_SHORT).show()
            else { cfg.edit().putString("key", k).apply(); online(k) }
        }, LinearLayout.LayoutParams(-1, dp(48)))

        out = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(14), dp(12), dp(14), dp(12)); background = glass()
            text = "اول در صفحه پیام‌رسان کانال‌ها را بروزرسانی کن، بعد یکی از دکمه‌ها را بزن."
        }
        root.addView(ScrollView(this).apply { addView(out) },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12) })
        setContentView(root)
    }

    private val stop = setOf("که", "این", "آن", "با", "برای", "از", "در", "به", "را", "هم", "است", "شد",
        "شده", "شود", "کرد", "کرده", "های", "ها", "یک", "تا", "بر", "اما", "یا", "خود", "کند", "بود", "می")

    private fun offline() {
        val data = collect()
        if (data.isEmpty()) { out.text = "پیام ذخیره‌شده‌ای وجود ندارد."; return }
        val sb = StringBuilder()
        for ((ch, msgs) in data) {
            val sents = msgs.flatMap { it.split(Regex("[.!؟?۔\\n]+")) }.map { it.trim() }.filter { it.length > 15 }
            val words = { s: String -> s.split(Regex("[\\s،,:;()«»\"'…\\-]+")).filter { it.length >= 3 && it !in stop } }
            val freq = HashMap<String, Int>()
            sents.forEach { s -> words(s).forEach { freq[it] = (freq[it] ?: 0) + 1 } }
            val top = sents.withIndex().sortedByDescending { (_, s) ->
                val w = words(s); if (w.isEmpty()) 0.0 else w.sumOf { freq[it] ?: 0 }.toDouble() / sqrt(w.size.toDouble())
            }.take(2).sortedBy { it.index }.map { it.value }
            sb.append("• @").append(ch).append("\n")
            sb.append(if (top.isEmpty()) msgs.last().take(200) else top.joinToString("\n")).append("\n\n")
        }
        out.text = sb.toString().trim()
    }

    private fun online(key: String) {
        val data = collect()
        if (data.isEmpty()) { out.text = "پیام ذخیره‌شده‌ای وجود ندارد."; return }
        out.text = "در حال خلاصه‌سازی…"
        val text = data.entries.joinToString("\n\n") { (c, m) -> "@$c:\n" + m.joinToString("\n- ", "- ") }.take(12000)
        Thread {
            val result = try {
                val body = JSONObject()
                    .put("model", "claude-sonnet-5-5")
                    .put("max_tokens", 1000)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content",
                        "پیام‌های زیر از چند کانال تلگرام است. برای هر کانال، خلاصه کوتاه فارسی (۱ تا ۲ جمله) بنویس.\n\n$text")))
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode in 200..299) {
                    JSONObject(c.inputStream.bufferedReader().readText())
                        .getJSONArray("content").getJSONObject(0).getString("text")
                } else "خطا (${c.responseCode}): کلید یا اینترنت را بررسی کن."
            } catch (e: Exception) { "اتصال برقرار نشد: ${e.message}" }
            runOnUiThread { out.text = result }
        }.start()
    }
}
