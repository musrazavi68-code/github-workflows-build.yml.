package com.musa.proxybot

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CrosswordActivity : AppCompatActivity() {

    private val bank: Map<String, List<String>> = mapOf(
        "سیاسی" to listOf("پایتخت فرانسه|پاریس", "پایتخت ژاپن|توکیو", "پایتخت ترکیه|آنکارا", "پایتخت مصر|قاهره",
            "پایتخت روسیه|مسکو", "پایتخت آلمان|برلین", "پایتخت چین|پکن", "پایتخت کانادا|اتاوا",
            "مقر سازمان ملل متحد در این شهر آمریکایی است|نیویورک"),
        "ورزشی" to listOf("تعداد بازیکنان هر تیم در زمین فوتبال (به حروف)|یازده",
            "ضربه‌ای که پس از خطا در محوطه جریمه زده می‌شود|پنالتی", "قهرمان جام جهانی ۲۰۲۲|آرژانتین",
            "میزبان جام جهانی ۲۰۲۲|قطر", "رنگ کارت اخطار داور|زرد", "بازیکن محافظ دروازه (کوتاه)|گلر",
            "نیوکمپ ورزشگاه کدام باشگاه است؟|بارسلونا", "قهرمان جام جهانی ۲۰۱۸|فرانسه"),
        "ادبیات" to listOf("سراینده شاهنامه|فردوسی", "سراینده گلستان و بوستان|سعدی", "لسان‌الغیب شیراز|حافظ",
            "سراینده مثنوی معنوی|مولوی", "نویسنده بوف کور|هدایت", "سراینده خمسه (پنج گنج)|نظامی",
            "شاعر نیشابوری رباعیات|خیام", "شاعر «هشت کتاب»|سپهری", "پدر شعر نو فارسی|نیما"),
        "فناوری" to listOf("شرکت سازنده آیفون|اپل", "موتور جست‌وجوی بزرگ|گوگل", "سیستم‌عامل گوگل برای موبایل|اندروید",
            "حافظه موقت کامپیوتر (کوتاه)|رم", "شرکت سازنده گوشی‌های گلکسی|سامسونگ",
            "سیستم‌عامل متن‌باز با نماد پنگوئن|لینوکس"),
        "اقتصادی" to listOf("واحد پول ژاپن|ین", "واحد پول اروپا|یورو", "واحد پول آمریکا|دلار", "واحد پول انگلستان|پوند",
            "فلز گران‌بهای زرد|طلا", "افزایش عمومی قیمت‌ها|تورم", "درآمد حاصل از سپرده بانکی|سود", "ارز دیجیتال مشهور|بیتکوین"),
        "عمومی" to listOf("بلندترین قله جهان|اورست", "بزرگ‌ترین اقیانوس|آرام", "سیاره سرخ|مریخ", "پایتخت ایران|تهران",
            "بزرگ‌ترین قاره|آسیا", "نزدیک‌ترین ستاره به زمین|خورشید", "تعداد روزهای هفته (به حروف)|هفت")
    )

    private val keywords = mapOf(
        "سیاسی" to listOf("مذاکره", "وزیر", "رئیس", "دولت", "مجلس", "تحریم", "سیاسی", "انتخابات", "نظامی"),
        "ورزشی" to listOf("گل", "فوتبال", "لیگ", "تیم", "پرسپولیس", "استقلال", "جام", "بازیکن"),
        "ادبیات" to listOf("شعر", "کتاب", "شاعر", "ادبیات", "رمان", "نویسنده", "حافظ", "سعدی"),
        "فناوری" to listOf("گوشی", "هوش مصنوعی", "اپل", "اندروید", "نرم‌افزار", "فناوری", "سامسونگ"),
        "اقتصادی" to listOf("دلار", "قیمت", "بورس", "تورم", "طلا", "بانک", "ارز", "سکه")
    )
    private val tagToCat = mapOf("خبری" to "سیاسی", "ورزشی" to "ورزشی", "فناوری" to "فناوری", "اقتصادی" to "اقتصادی")

    private val feed by lazy { getSharedPreferences("feed", MODE_PRIVATE) }
    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val prog by lazy { getSharedPreferences("cw", MODE_PRIVATE) }
    private lateinit var box: LinearLayout
    private lateinit var title: TextView
    private lateinit var chips: LinearLayout
    private var cat = "عمومی"
    private var restoring = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass(r: Int = 12) = GradientDrawable().apply {
        setColor(0x33FFFFFF); setStroke(dp(1), 0x66FFFFFF); cornerRadius = dp(r).toFloat()
    }
    private fun norm(s: String) = s.replace('ي', 'ی').replace('ك', 'ک').replace(" ", "")

    /** Most frequent topic among the user's cached channel messages and channel tags. */
    private fun detect(): String {
        val score = HashMap<String, Int>()
        val chs = feed.getString("chs", null)?.split(",")?.filter { it.isNotBlank() }
            ?: return "عمومی"
        for (c in chs) {
            val name = c.substringBefore("|"); val tag = c.substringAfter("|", "")
            tagToCat[tag]?.let { score[it] = (score[it] ?: 0) + 2 }
            val text = feed.getString("c_$name", "") ?: ""
            for ((k, ws) in keywords) ws.forEach { w ->
                score[k] = (score[k] ?: 0) + Regex(Regex.escape(w)).findAll(text).count()
            }
        }
        val best = score.maxByOrNull { it.value }
        return if (best == null || best.value == 0) "عمومی" else best.key
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cat = cfg.getString("cwcat", null) ?: detect()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(32), dp(14), dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
            )
        }
        title = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE) }
        root.addView(title)

        chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { addView(chips) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(box) },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        setContentView(root)
        build()
    }

    private fun build() {
        chips.removeAllViews()
        (listOf("خودکار") + bank.keys).forEach { name ->
            chips.addView(Button(this).apply {
                text = name; isAllCaps = false; setTextColor(Color.WHITE)
                background = glass(18)
                alpha = if (name == cat) 1f else 0.55f
                setOnClickListener {
                    if (name == "خودکار") { cfg.edit().remove("cwcat").apply(); cat = detect() }
                    else { cfg.edit().putString("cwcat", name).apply(); cat = name }
                    build()
                }
            }, LinearLayout.LayoutParams(-2, dp(40)).apply { setMargins(dp(3), 0, dp(3), 0) })
        }

        box.removeAllViews()
        val items = bank[cat] ?: emptyList()
        val rowBoxes = ArrayList<List<EditText>>()
        items.forEachIndexed { idx, item ->
            val clue = item.substringBefore("|"); val ans = item.substringAfter("|")
            box.addView(TextView(this).apply {
                text = "${idx + 1}. $clue  (${ans.length} حرف)"; setTextColor(Color.WHITE); textSize = 14f
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val boxes = ArrayList<EditText>()
            val saved = (prog.getString("${cat}_$idx", "") ?: "").padEnd(ans.length, ' ')
            for (i in ans.indices) {
                val et = EditText(this).apply {
                    gravity = Gravity.CENTER; textSize = 18f; setTextColor(Color.WHITE)
                    background = glass(8); setPadding(0, 0, 0, 0)
                    filters = arrayOf(android.text.InputFilter.LengthFilter(1))
                    isSingleLine = true
                }
                boxes.add(et)
                row.addView(et, LinearLayout.LayoutParams(dp(38), dp(44)).apply { setMargins(dp(2), dp(4), dp(2), 0) })
            }
            restoring = true
            boxes.forEachIndexed { i, et -> if (saved[i] != ' ') et.setText(saved[i].toString()) }
            restoring = false
            boxes.forEachIndexed { i, et ->
                et.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (restoring) return
                        prog.edit().putString("${cat}_$idx",
                            boxes.joinToString("") { it.text.toString().ifEmpty { " " } }).apply()
                        if (!s.isNullOrEmpty() && i < boxes.size - 1) boxes[i + 1].requestFocus()
                        evaluate(boxes, ans); updateTitle(items)
                    }
                })
            }
            evaluate(boxes, ans)
            rowBoxes.add(boxes)
            box.addView(row)
        }
        updateTitle(items)
    }

    private fun evaluate(boxes: List<EditText>, ans: String) {
        val joined = boxes.joinToString("") { it.text.toString() }
        val color = when {
            joined.length < boxes.size -> Color.WHITE
            norm(joined) == norm(ans) -> 0xFF7CFC9A.toInt()
            else -> 0xFFFF8A80.toInt()
        }
        boxes.forEach { it.setTextColor(color) }
    }

    private fun updateTitle(items: List<String>) {
        val solved = items.indices.count { i ->
            norm(prog.getString("${cat}_$i", "") ?: "") == norm(items[i].substringAfter("|"))
        }
        title.text = "جدول اطلاعات عمومی · $cat · $solved از ${items.size}"
    }
}
