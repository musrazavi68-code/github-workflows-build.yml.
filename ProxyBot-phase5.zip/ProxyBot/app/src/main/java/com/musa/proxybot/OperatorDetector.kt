package com.musa.proxybot

object OperatorDetector {
    fun detect(input: String): String {
        var d = input.filter { it.isDigit() }
        d = when {
            d.startsWith("0098") -> d.drop(4)
            d.startsWith("98") -> d.drop(2)
            d.startsWith("0") -> d.drop(1)
            else -> d
        }
        if (d.startsWith("21") && d.length == 10) return "تلفن ثابت تهران (۰۲۱)"
        if (d.length != 10 || !d.startsWith("9")) return "شماره معتبر نیست"
        val p = d.substring(0, 3).toInt()
        return when {
            p == 932 -> "تالیا"
            p in 910..919 || p in 990..999 -> "همراه اول"
            p in 930..939 || p in 900..905 || p == 941 -> "ایرانسل"
            p in 920..922 -> "رایتل"
            else -> "نامشخص"
        }
    }
}
