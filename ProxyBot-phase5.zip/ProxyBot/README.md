1. این پوشه را کامل (با پوشه مخفی .github) در یک Repository جدید در GitHub آپلود کن.
2. به تب Actions برو، Build APK را اجرا کن (Run workflow).
3. بعد از پایان، فایل ProxyBot-APK را از بخش Artifacts دانلود و نصب کن.
